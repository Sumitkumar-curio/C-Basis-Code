#include <stdio.h> //Avergae of two number.
 
float average(float a, float b) {
        return (a+b)/2;
    }
int main(){
    
    printf("the average of 100 and 200 is %f", average(100,200));
}