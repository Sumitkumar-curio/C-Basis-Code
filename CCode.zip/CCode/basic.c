#include <stdio.h>

int main(){
    printf("Hello World");
    return 0;

}
//Run code by keyboard shortcut- Shift+alt+Enter.
