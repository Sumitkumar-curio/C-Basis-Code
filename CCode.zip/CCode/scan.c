#include <stdio.h>

int main(){
    int  sumit;
    printf("\n Please enter the value of Sumitkumar ");
    scanf("%d", &sumit);
    printf("The value is %d", sumit);

}
